
var sectionBoxList=document.getElementsByClassName("sectionBoxList");
var subSec1BoxList=document.getElementsByClassName("subsection1BoxList")
var subSec2BoxList=document.getElementsByClassName("subsection2BoxList")
var sectionaddButton=document.getElementById("sectionAddButton");
var subsec1addButton=document.getElementById("subSec1AddButton");
var subsec2addButton=document.getElementById("subSec2AddButton");
var adminContainer=document.getElementById("adminContainer");
var addSectionPopUp=document.getElementById("addSectionPopUp");
var addSecPopUpHead=document.getElementById("addSecPopUpHead");
var selectSection=document.getElementsByClassName("selectSection");
var selectSubSec1=document.getElementsByClassName("selectSubSec1");
var selectSubSec2=document.getElementsByClassName("selectSubSection2");

var section="";
var sectionVal=0;
var subSec1Val=0;
var subSec2Val=0;


var sectionViewJson=""
var subSection1ViewJson="";
var subSection2ViewJson="";

function viewOrganizeCategories(){
	sectionViewUi();	
	subSec1ViewUi();
	subSec2ViewUi();
	var profile=document.getElementById("profile");
	var companyOwner=document.getElementById("companyOwner");
	var createdName=document.getElementById("createdName");
	profile.textContent=sectionViewJson.User.firstName.substring(0,1);
	companyOwner.textContent=sectionViewJson.User.firstName+" "+sectionViewJson.User.lastName;
	createdName.textContent=sectionViewJson.User.email;
	
	if(sectionBoxList.length>=1){
		sectionBoxList[0].classList.add("selectSection");
	}
	if(subSec1BoxList.length>=1){
		subSec1BoxList[0].classList.add("selectSubSection1");
	}
	if(subSec2BoxList.length>=1){
		subSec2BoxList[0].classList.add("selectSubSection2");
	}
}




var checkSectionCondition=false;
var checkSubSection1Condition=false;

function sectionViewUi(){
	var sectionList=document.getElementById("sectionList");

	
	
	var xhr=new XMLHttpRequest();
	xhr.onreadystatechange=function(){
		if(xhr.readyState==4){
			if(xhr.status==200){
				sectionViewJson=JSON.parse(this.responseText);
				var json=sectionViewJson;
				if(json.statusCode==200){
					sectionList.innerHTML="";
					
					if(json.sectionList.length<=0){
						
						subsec1addButton.style.display="none";
					}
					else{
						if(!checkSectionCondition){
							sectionVal=json.sectionList[0].SectionId;
						}
						subsec1addButton.style.display="block";
					}
					
				
					for(var i=0;i<json.sectionList.length;i++){
						var sectionBoxList=document.createElement("div");
						sectionList.appendChild(sectionBoxList);
						sectionBoxList.classList.add("sectionBoxList");
						sectionBoxList.setAttribute("onclick","clickSection('"+json.sectionList[i].SectionId+","+i+"')");
						
						var secName=document.createElement("p");
						sectionBoxList.appendChild(secName);
						secName.classList.add("secName");
						secName.textContent=json.sectionList[i].SectionName;
						secName.title=json.sectionList[i].SectionName;
						
						var secDes=document.createElement("p");
						sectionBoxList.appendChild(secDes);
						secDes.classList.add("secDes");
						secDes.textContent=json.sectionList[i].Description;
						secDes.title=json.sectionList[i].Description;
						
					}
					
					
					
				}
			}
			else if(this.status==301){
				window.location.href="/ZohoDesk/signIn.html"
			}
		}
	}
	
	xhr.open("POST","Organize/sectionView",false);
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	
	xhr.send();
	
}



function subSec1ViewUi(){
    var subSection1List=document.getElementById("subSection1List");
    
	var xhr=new XMLHttpRequest();
	xhr.onreadystatechange=function(){
		if(xhr.readyState==4){
			if(xhr.status==200){
				subSection1ViewJson=JSON.parse(this.responseText);
				var json=subSection1ViewJson;
				if(json.statusCode==200){
					subSection1List.innerHTML="";
					if(json.subSec1.length<=0){
					    subsec2addButton.style.display="none";
					}
					else{
						if(!checkSubSection1Condition){
							subSec1Val=json.subSec1[0].subSectionId;
						}	
						subsec2addButton.style.display="block";
					}
					for(var i=0;i<json.subSec1.length;i++){
						var subsection1BoxList=document.createElement("div");
						subSection1List.appendChild(subsection1BoxList);
						subsection1BoxList.classList.add("subsection1BoxList");
						subsection1BoxList.setAttribute("onclick","clickSub1Section('"+json.subSec1[i].subSectionId+","+i+"')");
						
						var secName=document.createElement("p");
						subsection1BoxList.appendChild(secName);
						secName.classList.add("secName");
						secName.textContent=json.subSec1[i].subSectionName;
						secName.title=json.subSec1[i].subSectionName;
						
						var secDes=document.createElement("p");
						subsection1BoxList.appendChild(secDes);
						secDes.classList.add("secDes");
						secDes.textContent=json.subSec1[i].Description;
						secDes.title=json.subSec1[i].Description;
							
				    }
				}
			}
			else if(this.status==301){
				window.location.href="/ZohoDesk/signIn.html"
			}
		}
	}

	
	xhr.open("POST","Organize/subSection1View",false);
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	xhr.send("sectionVal="+sectionVal);
}



function subSec2ViewUi(){
	var subSection2List=document.getElementById("subSection2List");
	var xhr=new XMLHttpRequest();
	xhr.onreadystatechange=function(){
		if(xhr.readyState==4){
			if(xhr.status==200){
				subSection2ViewJson=JSON.parse(this.responseText);
				var json=subSection2ViewJson;
				if(json.statusCode==200){
					subSection2List.innerHTML="";
					
					if(json.subSec2.length>0){
						subSec2Val=json.subSec2[0].subSectionId;
					}
					for(var i=0;i<json.subSec2.length;i++){
						var subsection2BoxList=document.createElement("div");
						subSection2List.appendChild(subsection2BoxList);
						subsection2BoxList.classList.add("subsection2BoxList");
						subsection2BoxList.setAttribute("onclick","clickSub2Section('"+json.subSec2[i].subSectionId+","+i+"')");
						
						var secName=document.createElement("p");
						subsection2BoxList.appendChild(secName);
						secName.classList.add("secName");
						secName.textContent=json.subSec2[i].subSectionName;
						secName.title=json.subSec2[i].subSectionName;
						
						var secDes=document.createElement("p");
						subsection2BoxList.appendChild(secDes);
						secDes.classList.add("secDes");
						secDes.textContent=json.subSec2[i].Description;
						secDes.title=json.subSec2[i].Description;
						
					}
				}
			}
			else if(this.status==301){
				window.location.href="/ZohoDesk/signIn.html"
			}
		}
	}
	
	xhr.open("POST","Organize/subSection2View",false);
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	xhr.send("subSec1Val="+subSec1Val);
}


var index1=0;
function clickSection(val){
	
	

	
	var split=val.split(",");
	sectionVal=split[0];
	index1=split[1];
	subSec1Val=0;
    subSec2Val=0;
    checkSectionCondition=true;
    checkSubSection1Condition=false;
    
    sectionViewUi();
	subSec1ViewUi();
	subSec2ViewUi();
    
	if(selectSection.length>0){
		selectSection[0].classList.remove("selectSection");
	}
	
	sectionBoxList[split[1]].classList.add("selectSection");
	if(subSec1BoxList.length>0){
		subSec1BoxList[0].classList.add("selectSubSection1");
	}
	if(subSec2BoxList.length>0){
		subSec2BoxList[0].classList.add("selectSubSection2");
	}
	
	
	
	
}



function clickSub1Section(val){
	
	var split=val.split(",");
	subSec1Val=split[0];
	
	checkSubSection1Condition=true;
	sectionViewUi();
	subSec1ViewUi();
	subSec2ViewUi();
	if(selectSubSec1.length>0){
		selectSubSec1[0].classList.remove("selectSubSection1");
	}
	subSec1BoxList[split[1]].classList.add("selectSubSection1");
	if(subSec2BoxList.length>0){
		subSec2BoxList[0].classList.add("selectSubSection2");
	}
	
	sectionBoxList[index1].classList.add("selectSection");
	
}

function clickSub2Section(val){
	
	var split=val.split(",");
	subSec2Val=split[0];
	if(selectSubSec2.length>0){
		selectSubSec2[0].classList.remove("selectSubSection2");
	}
	subSec2BoxList[split[1]].classList.add("selectSubSection2");
	
}








function sectionSaveButton(){
	var sectionName=document.getElementById("sectionName").value;
	var sectionDescription=document.getElementById("sectionDescription").value;
	var sectionVisibility=document.getElementById("sectionVisibility").value;
	
	
	var xhr=new XMLHttpRequest();
	xhr.onreadystatechange=function(){
		if(xhr.readyState==4){
			if(xhr.status==200){
				var json=JSON.parse(this.responseText);
				if(json.statusCode==200){
					alert(json.detailedMessage);
					adminContainer.style.filter="opacity(1)";
					adminContainer.style.pointerEvents="auto";
					addSectionPopUp.style.transform="translate(183%)";
					sectionVal=0;
					subSec1Val=0;
					subSec2Val=0;
					viewOrganizeCategories();
					sectionName="";
					sectionDescription="";
					sectionVisibility="";
				}
			}
		}
	}
	
	if(sectionName.trim()=="" || sectionName==""){
		alert("Section name must be filled out");
	}
	else{
		if(section=="section"){
			xhr.open("POST","Organize/addSection",false);
			xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
			xhr.send("section="+section+"&sectionName="+sectionName+"&sectionDescription="+sectionDescription+"&sectionVisibility="+sectionVisibility);
		}
		if(section=="subSec1"){
			xhr.open("POST","Organize/addSection",false);
			xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
			xhr.send("section="+section+"&secVal="+sectionVal+"&sectionName="+sectionName+"&sectionDescription="+sectionDescription+"&sectionVisibility="+sectionVisibility);
		}
		if(section=="subSec2"){
			xhr.open("POST","Organize/addSection",false);
			xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
			xhr.send("section="+section+"&subSec1Val="+subSec1Val+"&sectionName="+sectionName+"&sectionDescription="+sectionDescription+"&sectionVisibility="+sectionVisibility);
		}
	}
	
	
	
}


function sectionCancelButton(){
	adminContainer.style.filter="opacity(1)";
	adminContainer.style.pointerEvents="auto";
	addSectionPopUp.style.transform="translate(183%)";
}

function sectionAddButton(sec){
	section=sec;
	addSecPopUpHead.textContent="Add Section";
	adminContainer.style.filter="opacity(0.1)";
	adminContainer.style.pointerEvents="none";
	addSectionPopUp.style.transform="translateX(0%)";

}

function subSec1AddButton(sec){
	section=sec;
	addSecPopUpHead.textContent="Add Sub Section";
	adminContainer.style.filter="opacity(0.1)";
	adminContainer.style.pointerEvents="none";
	addSectionPopUp.style.transform="translateX(0%)";
}

function subSec2AddButton(sec){
	section=sec;
	addSecPopUpHead.textContent="Add Sub Section";
	adminContainer.style.filter="opacity(0.1)";
	adminContainer.style.pointerEvents="none";
	addSectionPopUp.style.transform="translateX(0%)";
}
