function userSignIn(){
	 var name=document.getElementById("email1").value;
	 var password=document.getElementById("password1").value;
	  console.log("&email="+name+"&password="+password);
	 var xhr=new XMLHttpRequest();
	 xhr.onreadystatechange=function(){
		 if(xhr.readyState==4){
			 if(this.status==200){
				var resp = JSON.parse(this.responseText);
				if(resp.statusCode == 200){
					 console.log(resp.detailedMessage);	
					 window.location.href="./Adminorganize.html";
				}
				else if(name=="" && password==""){
					alert("Email and password must be filled out");
				}
				else if(name==""){
					alert("Email must be filled out");
				}
				else if(password==""){
					alert("password must be filled out");
				}
				
				else{
					
					alert("Invalid email or Password");
					document.getElementById("email1").value="";
					document.getElementById("password1").value="";
				}
			 }
		 }
	 }
	 xhr.open("POST","signIn");
	 xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	 xhr.send("email="+name+"&password="+password);
	 
 }
 