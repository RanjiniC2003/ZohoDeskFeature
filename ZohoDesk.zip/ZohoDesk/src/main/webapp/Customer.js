var clickClass=document.getElementsByClassName("clickClass");
var Home=document.getElementById("home");
var MyPage=document.getElementById("myPage");
var SignIn=document.getElementById("signIn");
var SignUp=document.getElementById("signUp");
var bodyHeight=document.getElementById("body");
var ticketView=document.getElementById("ticketView");
var signUpPage=document.getElementById("signUpPage");
var signInPage=document.getElementById("signInPage");
var ticketDetails=document.getElementById("ticketDetails");

var customerContainer=document.getElementById("customerContainer");
var ticketPopUp=document.getElementById("ticketPopUp");
var welcome=document.getElementById("welcome");


var viewPageJson="";
var checkAuthentication;

function home(){
	if(clickClass.length>0){
		clickClass[0].classList.remove("clickClass");
	}
	Home.classList.add("clickClass")
	bodyHeight.style.backgroundPosition="0px -269px";
	bodyHeight.style.height="400px";
	ticketView.style.display="block";
	signUpPage.style.display="none";
	signInPage.style.display="none";
	ticketDetails.style.display="none";
	welcome.style.display="block";
	
}

function myPage(){
	if(clickClass.length>0){
		clickClass[0].classList.remove("clickClass");
	}
	MyPage.classList.add("clickClass");
	bodyHeight.style.backgroundPosition="0px -427px";
	bodyHeight.style.height="91px";
	ticketView.style.display="none";
	signUpPage.style.display="none";
	welcome.style.display="none";

	if(checkAuthentication){
		ticketDetails.style.display="block";
		signInPage.style.display="none";
	}
	else{
		ticketDetails.style.display="none";
		signInPage.style.display="block";
	}
	
	viewTicket("viewAllTicket");
}

function signIn(){
	if(clickClass.length>0){
		clickClass[0].classList.remove("clickClass");
	}
	SignIn.classList.add("clickClass");
	bodyHeight.style.backgroundPosition="0px -427px";
	bodyHeight.style.height="91px";
	ticketView.style.display="none";
	signUpPage.style.display="none";
	signInPage.style.display="block";
	ticketDetails.style.display="none";
	welcome.style.display="none";
}


function signUp(){
	if(clickClass.length>0){
		clickClass[0].classList.remove("clickClass");
	}
	SignUp.classList.add("clickClass");
	bodyHeight.style.backgroundPosition="0px -427px";
	bodyHeight.style.height="91px";
	ticketView.style.display="none";
	signUpPage.style.display="block";
	signInPage.style.display="none";
	ticketDetails.style.display="none";
	welcome.style.display="none";
	
	
}


function customerProfile(){
	document.getElementById("logOutPopUp").style.display="block";
}

function logOutCancel(){
	document.getElementById("logOutPopUp").style.display="none";
}


var sectionViewJson=""
var subSection1ViewJson="";
var subSection2ViewJson="";
var productNameList=document.getElementById("productName");
var subSec1List=document.getElementById("subSec1");
var subSec2List=document.getElementById("subSec2");

function bookTicket(){
	ticketPopUp.style.transform="translateX(-8%)";
	customerContainer.style.pointerEvents="none";
	customerContainer.style.filter="opacity(0.4)";
	productDropDown();
	subSecView1();
	subSecView2();
}

function productDropDown(){
	
	var xhr=new XMLHttpRequest();
	xhr.onreadystatechange=function(){
		if(xhr.readyState==4){
			if(xhr.status==200){
				
				sectionViewJson=JSON.parse(this.responseText);
				
				var json=sectionViewJson;				
				if(json.statusCode==200){
					productNameList.innerHTML="";
					if(json.sectionList.length>0){
						for(var i=0;i<json.sectionList.length;i++){
							var option=document.createElement("option");
							productNameList.appendChild(option);
							option.textContent=json.sectionList[i].SectionName;
							option.setAttribute("value",json.sectionList[i].SectionId);
						}
						
					}
			    }	
			}
		}
	}
	
	xhr.open("POST","Customer/sectionView",false);
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	xhr.send();
}


function subSecView1(){
	
	var sectionVal=productNameList.value;
	var xhr=new XMLHttpRequest();
	xhr.onreadystatechange=function(){
		if(xhr.readyState==4){
			if(xhr.status==200){
				subSection1ViewJson=JSON.parse(this.responseText);
				var json=subSection1ViewJson;
			
				if(json.statusCode==200){
					subSec1List.innerHTML="";
					var op=document.createElement("option");
					subSec1List.appendChild(op);
					op.setAttribute("value",-1);
					op.textContent="Other";
					if(json.subSec1.length>0){
						for(var i=0;i<json.subSec1.length;i++){
							var option=document.createElement("option");
							subSec1List.appendChild(option);
							option.setAttribute("value",json.subSec1[i].subSectionId);
							option.textContent=json.subSec1[i].subSectionName;
						}
					}
				}
				
				
			}
		}
	}
	
	xhr.open("POST","Customer/subSection1View",false);
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	xhr.send("sectionVal="+sectionVal);
}

function subSecView2(){
	
	subSectionVal1=subSec1List.value;
	
	subSec2List.innerHTML="";
	var op=document.createElement("option");
	subSec2List.appendChild(op);
	op.setAttribute("value",-1);
	op.textContent="Other";
	var xhr=new XMLHttpRequest();
	xhr.onreadystatechange=function(){
		if(xhr.readyState==4){
			if(xhr.status==200){
				
				subSection2ViewJson=JSON.parse(this.responseText);
				var json=subSection2ViewJson;
				
				if(json.statusCode==200){
					if(json.subSec2.length>0){
						for(var i=0;i<json.subSec2.length;i++){
							var option=document.createElement("option");
							subSec2List.appendChild(option);
							option.setAttribute("value",json.subSec2[i].subSectionId);
							option.textContent=json.subSec2[i].subSectionName;
						}
					}
				}
				
				
			}
		}
	}
	
	xhr.open("POST","Customer/subSection2View",false);
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	xhr.send("subSec1Val="+subSectionVal1);
}








function ticketSumbit(){
	var ticketSubject=document.getElementById("ticketSubject").value;
	var ticketDes=document.getElementById("ticketDes").value;
	var productName=document.getElementById("productName").value;
	var subSec1=document.getElementById("subSec1").value;
	var subSec2=document.getElementById("subSec1").value;
	var priority=document.getElementById("priority").value;
	

	var xhr=new XMLHttpRequest();
	xhr.onreadystatechange=function(){
		if(this.readyState==4){
			if(this.status==200){
				var json=JSON.parse(this.responseText);
				if(json.statusCode==200){
					alert(json.detailedMessage);
					ticketPopUp.style.transform="translateX(117%)";
					customerContainer.style.pointerEvents="auto";
					customerContainer.style.filter="opacity(1)";
					viewTicket("viewMyTicket");
				}
				else{
					alert(json.detailedMessage);
				}
			}
		}
	}
	
	
	xhr.open("POST","Customer/addTicket");
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	xhr.send("ticketSubject="+ticketSubject+"&ticketDes="+ticketDes+"&productName="+productName+"&subSec1="+subSec1+"&subSec2="+subSec2+"&priority="+priority);
}

function ticketCancel(){
	ticketPopUp.style.transform="translateX(117%)";
	customerContainer.style.pointerEvents="auto";
	customerContainer.style.filter="opacity(1)";
}



function viewTicket(type){
	var viewAllticketdiv=document.getElementById("viewAllticketdiv");
	var viewMyticketdiv=document.getElementById("viewMyticketdiv");
	
	
	var allType=document.getElementById("allType");
	var myType=document.getElementById("myType");
	
	var xhr=new XMLHttpRequest();
	xhr.onreadystatechange=function(){
		if(this.readyState==4){
			if(this.status==200){
				var json=JSON.parse(this.responseText);
				if(json.statusCode==200){
					viewMyticketdiv.innerHTML="";
					viewAllticketdiv.innerHTML="";
					var checkType=document.getElementsByClassName("checkType");
					if(checkType.length>0){
						checkType[0].classList.remove("checkType");
					}
					
					if(type=="viewAllTicket"){
						allType.classList.add("checkType");
						viewtic(viewAllticketdiv,json);
						viewMyticketdiv.style.display="none";
						viewAllticketdiv.style.display="block";
					}
					else if(type=="viewMyTicket"){
						myType.classList.add("checkType");
						viewtic(viewMyticketdiv,json);
						viewMyticketdiv.style.display="block";
						viewAllticketdiv.style.display="none";
					}
				}
			}
		}
	}
	
	xhr.open("POST","Customer/viewTickets",false);
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	xhr.send("type="+type);
}


function viewtic(div,json){
	var noTicket=document.getElementById("noTicket");
	if(json.arr.length>0){
		noTicket.style.display="none";
		
		for(var i=0;i<json.arr.length;i++){
			var ticketDiv=document.createElement("div");
			div.appendChild(ticketDiv);
			ticketDiv.classList.add("ticketDiv");
			
			var ticDeatail=document.createElement("div");
			ticketDiv.appendChild(ticDeatail);
			ticDeatail.classList.add("ticDeatail");
			
			var createrProfile=document.createElement("div");
			ticketDiv.appendChild(createrProfile);
			createrProfile.classList.add("createrProfile");
			
			
			var view=document.createElement("div");
			createrProfile.appendChild(view);
			view.classList.add("view");
			view.setAttribute("onclick","view('"+json.arr[i].ticketId+"')");
			view.textContent="View";
			
			/*<i class="fa-duotone fa-user fa-beat-fade fa-xl" style="--fa-primary-color: #e5e0e0; --fa-secondary-color: #000000;"></i>*/
			
			var icon=document.createElement("i");
			createrProfile.appendChild(icon);
			icon.classList.add("fa-regular");
			icon.classList.add("fa-user");
		
/*		<i class="fa-duotone fa-user fa-fade"></i>*/
			
			
			
			var names=document.createElement("div");
			ticDeatail.appendChild(names);
			names.classList.add("names");
			
			var sectionName=document.createElement("p");
			names.appendChild(sectionName);
			sectionName.classList.add("sectionName");
			sectionName.textContent=json.arr[i].section.SectionName;
			sectionName.title=json.arr[i].section.SectionName;
			
			var subName=document.createElement("p");
			names.appendChild(subName);
			subName.classList.add("subName");
			subName.textContent=json.arr[i].Subject;
			subName.title=json.arr[i].Subject;
			
			
			
			var createDetails=document.createElement("div");
			ticDeatail.appendChild(createDetails);
			createDetails.classList.add("createDetails");
			
			
			var creatorName=document.createElement("p");
			createDetails.appendChild(creatorName);
			creatorName.classList.add("creatorName");
			creatorName.textContent=json.arr[i].createdBy.firstName;
			creatorName.title=json.arr[i].createdBy.firstName;
			
			
			
			var createDate=document.createElement("p");
			createDetails.appendChild(createDate);
			createDate.classList.add("createDate");
			createDate.textContent=json.arr[i].createdOn.toString().split("-").reverse().join("-");
			createDate.title=json.arr[i].createdOn.toString().split("-").reverse().join("-");
			
			
	    }
	}
	else{
		noTicket.style.display="flex";
		div.style.display="none";
	}
}


function UsersignIn(){
	var email=document.getElementById("customerEmail").value;
	var password=document.getElementById("customerPassword").value;
	
	var xhr=new XMLHttpRequest();
	xhr.onreadystatechange=function(){
		if(xhr.readyState==4){
			if(xhr.status==200){
				var json=JSON.parse(xhr.responseText);
				if(json.statusCode==200){
					alert(json.detailedMessage);
					document.getElementById("customerEmail").value="";
					document.getElementById("customerPassword").value="";
					viewCustomerPage();
					signInPage.style.display="none";
					ticketView.style.display="block";
					home()
				}
				else{
					alert(json.detailedMessage);
				}
			}
		}
	}
	
	xhr.open("POST","CustomerSignServlet/signIn");
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	xhr.send("email="+email+"&password="+password);
}

function UsersignUp(){
	var firstName=document.getElementById("firstName").value;
	var lastName=document.getElementById("lastName").value;
	var email=document.getElementById("email").value;
	var password=document.getElementById("password").value;
	var phoneNumber=document.getElementById("phoneNumber").value;
	
	var xhr=new XMLHttpRequest();
	xhr.onreadystatechange=function(){
		if(xhr.readyState==4){
			if(xhr.status==200){
				var json=JSON.parse(this.responseText);
				if(json.statusCode==200){
					alert(json.detailedMessage);
					document.getElementById("firstName").value="";
					document.getElementById("lastName").value="";
					document.getElementById("email").value="";
					document.getElementById("password").value="";
					document.getElementById("phoneNumber").value="";
					viewCustomerPage();
					signUpPage.style.display="none";
					ticketView.style.display="block";
					home()
				}
				else{
					alert(json.detailedMessage);
				}
			}
		}
	}
	
	
	xhr.open("POST","CustomerSignServlet/signUp");
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	xhr.send("firstName="+firstName+"&lastName="+lastName+"&email="+email+"&password="+password+"&phoneNumber="+phoneNumber);
	
}
 
 

 
function viewCustomerPage(){
	var comName=document.getElementById("comName");

	var xhr=new XMLHttpRequest();
	xhr.onreadystatechange=function(){
		if(xhr.readyState==4){
			if(xhr.status==200){
				var json=JSON.parse(this.responseText);
				if(json.statusCode==200){
					comName.textContent=json.company.companyName;
					welcome.textContent="Welcome to "+json.company.companyName;
					var xhr2=new XMLHttpRequest();
					xhr2.onreadystatechange=function(){
						if(xhr2.readyState==4){
							if(xhr2.status==200){
								checkAuthentication=true;
								viewPageJson=JSON.parse(this.responseText);
								var json1=viewPageJson;
								var customerProfile=document.getElementById("customerProfile");
								var cusProfile=document.getElementById("cusProfile");
								var cusName=document.getElementById("cusName");
								var cusEmail=document.getElementById("cusEmail");
								
								SignIn.style.display="none";
								SignUp.style.display="none";
								customerProfile.style.display="flex";
								customerProfile.textContent=json1.user.firstName.substring(0,1);
								cusProfile.textContent=json1.user.firstName.substring(0,1);
								cusName.textContent=json1.user.firstName+" "+json1.user.lastName;
								cusEmail.textContent=json1.user.email;
							}
							else{
								checkAuthentication=false;
								var customerProfile=document.getElementById("customerProfile");
								customerProfile.style.display="none";
								SignIn.style.display="block";
								SignUp.style.display="block";
							}
						}
					}
					
					xhr2.open("POST","Customer/viewCustomerPage",false);
					xhr2.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
					xhr2.send();
				}
			}
		}
	}
	xhr.open("POST","GetOwnerDetails",false);
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	xhr.send();
} 




 function logOut(){
	 var xhr=new XMLHttpRequest();
	 xhr.onreadystatechange=function(){
		if(this.readyState==4){
			if(this.status==200){
				document.getElementById("logOutPopUp").style.display="none";
				viewCustomerPage();
				myPage()
				home();
				
			}
		} 
	 }
	 
	 xhr.open("POST","logOut/logout");
	 xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	 xhr.send();
 }

var ticketDetailsView=document.getElementById("ticketDetailsView");
var customerContainer=document.getElementById("customerContainer");
var repValue=document.getElementById("repValue");
function view(id){

	
	var xhr=new XMLHttpRequest();
	xhr.onreadystatechange=function(){
		if(xhr.readyState==4){
			if(xhr.status==200){
				
				var json=JSON.parse(this.responseText);
			
				if(json.statusCode==200){
					ticketDetailsView.style.transform="translateX(-5%)";
					customerContainer.style.pointerEvents="none";
					customerContainer.style.filter="opacity(0.2)";
					/*console.log(json.arr);*/
					document.getElementById("subValue").textContent=json.ticket.Subject;
					document.getElementById("desValue").textContent=json.ticket.Description;
					document.getElementById("productValue").textContent=json.ticket.section.SectionName;
					document.getElementById("priorityValue").textContent=json.ticket.priority;
				
					document.getElementById("statusValue").textContent=json.ticket.status;
					
					var noRepValue=document.getElementById("noRepValue");
					var repValue=document.getElementById("repValue");
					if(json.arr.length>0){
						repValue.innerHTML="";
						noRepValue.style.display="none";
						for(var i=0;i<json.arr.length;i++){
							var replyDiv=document.createElement("div");
							repValue.appendChild(replyDiv);
							replyDiv.classList.add("replyDiv");
							replyDiv.textContent=(i+1)+" ) "+json.arr[i].reply;
						}
					}
					else{
						noRepValue.style.display="block";
					}
				}
			}
		}
	}
	
	xhr.open("POST","Customer/getTicketDetails") ;
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	xhr.send("ticketId="+id);
	
	
}

function ticketDetailsViewCancel(){
	repValue.innerHTML="";
	ticketDetailsView.style.transform="translateX(251%)";
	customerContainer.style.pointerEvents="auto";
	customerContainer.style.filter="opacity(1)";
					
}














