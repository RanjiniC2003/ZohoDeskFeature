



function viewTicket(type){
	var TicketList=document.getElementById("TicketList");
	var xhr=new XMLHttpRequest();
	xhr.onreadystatechange=function(){
		if(this.readyState==4){
			if(this.status==200){
			    
				var json=JSON.parse(this.responseText);
				if(json.statusCode==200){
					TicketList.innerHTML="";
					viewtic(TicketList,json);
					
				}
			}
			else if(this.status==301){
				window.location.href="/ZohoDesk/signIn.html"
			}
		}
	}
	
	xhr.open("POST","Organize1/viewTickets",false);
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	xhr.send("type="+type);
}

function viewtic(div,json){
	var noTicket=document.getElementById("noTicket");
	var count=document.getElementById("count");
	count.textContent=" ( "+json.arr.length+" )";
	if(json.arr.length>0){
		noTicket.style.display="none";
		for(var i=0;i<json.arr.length;i++){
			var ticketDiv=document.createElement("div");
			div.appendChild(ticketDiv);
			ticketDiv.classList.add("ticketDiv");
			
			var ticDeatail=document.createElement("div");
			ticketDiv.appendChild(ticDeatail);
			ticDeatail.classList.add("ticDeatail");
			
			var editDelete=document.createElement("div");
			ticketDiv.appendChild(editDelete);
			editDelete.classList.add("editDelete");
			
			var edit=document.createElement("div");
			editDelete.appendChild(edit);
			edit.classList.add("edit");
			edit.setAttribute("onclick","edit('"+json.arr[i].ticketId+"')");
			edit.textContent="Edit";
			
			var reply=document.createElement("div");
			editDelete.appendChild(reply);
			reply.classList.add("reply");
			reply.setAttribute("onclick","reply('"+json.arr[i].ticketId+"')");
			reply.textContent="Reply";
			
			
			var view=document.createElement("div");
			editDelete.appendChild(view);
			view.classList.add("view");
			view.setAttribute("onclick","view('"+json.arr[i].ticketId+"')");
			view.textContent="View";
			
			var deleteTicket=document.createElement("i");
			editDelete.appendChild(deleteTicket);
			deleteTicket.classList.add("fa-sharp");
			deleteTicket.classList.add("fa-solid");
			deleteTicket.classList.add("fa-trash");
			deleteTicket.setAttribute("onclick","deleteTicket('"+json.arr[i].ticketId+"')");
			
		
			var names=document.createElement("div");
			ticDeatail.appendChild(names);
			names.classList.add("names");
			
			var sectionName=document.createElement("p");
			names.appendChild(sectionName);
			sectionName.classList.add("sectionName");
			sectionName.textContent=json.arr[i].section.SectionName;
			sectionName.title=json.arr[i].section.SectionName;
			
			var subName=document.createElement("p");
			names.appendChild(subName);
			subName.classList.add("subName");
			subName.textContent=json.arr[i].Subject;
			subName.title=json.arr[i].Subject;
			
			
			
			var createDetails=document.createElement("div");
			ticDeatail.appendChild(createDetails);
			createDetails.classList.add("createDetails");
			
			
			var creatorName=document.createElement("p");
			createDetails.appendChild(creatorName);
			creatorName.classList.add("creatorName");
			creatorName.textContent=json.arr[i].createdBy.email;
			creatorName.title=json.arr[i].createdBy.email;
			
			
			
			var createDate=document.createElement("p");
			createDetails.appendChild(createDate);
			createDate.classList.add("createDate");
			createDate.textContent=json.arr[i].createdOn.toString().split("-").reverse().join("-");
			createDate.title=json.arr[i].createdOn.toString().split("-").reverse().join("-");
			
			
	    }
	    
	}
	else{
		noTicket.style.display="flex";
	}
	
}



function deleteTicket(ticketId){
	var xhr=new XMLHttpRequest();
	xhr.onreadystatechange=function(){
		if(this.readyState==4){
			if(this.status==200){
				var json=JSON.parse(this.responseText);
				if(json.statusCode==200){
					viewTicket("viewAllTicket");
					alert(json.detailedMessage);
					
				}
				else{
					alert(json.detailedMessage);
				}
			}
		}
	}
	
	xhr.open("POST","Organize1/deleteTicket",false);
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	xhr.send("ticketId="+ticketId);
	
}
var ticketId=0;

var updateTicketPopUp=document.getElementById("updateTicketPopUp");
var adminContainer=document.getElementById("adminContainer");
function edit(id){
	
	var xhr=new XMLHttpRequest();
	xhr.onreadystatechange=function(){
		if(this.readyState==4){
			if(this.status==200){
			
				var json=JSON.parse(this.responseText);
				document.getElementById("ticketSubject").value=json.ticket.Subject;
				document.getElementById("ticketDes").value=json.ticket.Description;
				document.getElementById("priority").value=json.ticket.priority;
				document.getElementById("status").value=json.ticket.status;
			}
		}
	}
	 
	xhr.open("POST","Organize1/getTicketDetails",false) ;
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	xhr.send("ticketId="+id);
	
	
	ticketId=id;
	updateTicketPopUp.style.transform="translateX(-7%)";
	adminContainer.style.pointerEvents="none";
	adminContainer.style.filter="opacity(0.3)";
}


function ticketUpdate(){
	var ticketSubject=document.getElementById("ticketSubject").value;
	var ticketDes=document.getElementById("ticketDes").value;
	var priority=document.getElementById("priority").value;
	var status=document.getElementById("status").value;
	
	
	
	var xhr=new XMLHttpRequest();
	xhr.onreadystatechange=function(){
		if(xhr.readyState==4){
			if(xhr.status==200){
				var json=JSON.parse(this.responseText);
				if(json.statusCode==200){
					updateTicketPopUp.style.transform="translateX(117%)";
					adminContainer.style.pointerEvents="auto";
					adminContainer.style.filter="opacity(1)";
					viewTicket("viewAllTicket");
					alert(json.detailedMessage);
					
					
				}
				else{
					alert(json.detailedMessage);
				}
			}
		}
	}
	xhr.open("POST","Organize1/updateTicket",false);
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	xhr.send("ticketSubject="+ticketSubject+"&ticketDes="+ticketDes+"&priority="+priority+"&status="+status+"&ticketId="+ticketId);
}

function ticketUpdateCancel(){
	updateTicketPopUp.style.transform="translateX(117%)";
	adminContainer.style.pointerEvents="auto";
	adminContainer.style.filter="opacity(1)";
}



var replyPopUp=document.getElementById("replyPopUp");
function reply(id){
    ticketId=id;
    replyPopUp.style.display="block";
}

function replyCancel(){
	replyPopUp.style.display="none";
}

function replySave(){
	var reply=document.getElementById("reply").value;
	var xhr=new XMLHttpRequest();
	xhr.onreadystatechange=function(){
		if(this.readyState==4){
			if(this.status==200){
				var json=JSON.parse(this.responseText);
				if(json.statusCode==200){
					alert(json.detailedMessage);
					replyPopUp.style.display="none";
					reply="";
				}
				else{
					alert(json.detailedMessage);
				}
			}
		}
	}
	xhr.open("POST","Organize1/addReply");
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	xhr.send("ticketId="+ticketId+"&reply="+reply);
}

var ticketDetailsView=document.getElementById("ticketDetailsView");
var adminContainer=document.getElementById("adminContainer");
var repValue=document.getElementById("repValue");
function view(id){

	
	var xhr=new XMLHttpRequest();
	xhr.onreadystatechange=function(){
		if(xhr.readyState==4){
			if(xhr.status==200){
				
				var json=JSON.parse(this.responseText);
			
				if(json.statusCode==200){
					ticketDetailsView.style.transform="translateX(-5%)";
					adminContainer.style.pointerEvents="none";
					adminContainer.style.filter="opacity(0.2)";
					/*console.log(json.arr);*/
					document.getElementById("subValue").textContent=json.ticket.Subject;
					document.getElementById("desValue").textContent=json.ticket.Description;
					document.getElementById("productValue").textContent=json.ticket.section.SectionName;
					document.getElementById("priorityValue").textContent=json.ticket.priority;
				
					document.getElementById("statusValue").textContent=json.ticket.status;
					
					var noRepValue=document.getElementById("noRepValue");
					var repValue=document.getElementById("repValue");
					if(json.arr.length>0){
						repValue.innerHTML="";
						noRepValue.style.display="none";
						for(var i=0;i<json.arr.length;i++){
							var replyDiv=document.createElement("div");
							repValue.appendChild(replyDiv);
							replyDiv.classList.add("replyDiv");
							replyDiv.textContent=(i+1)+" ) "+json.arr[i].reply;
						}
					}
					else{
						noRepValue.style.display="block";
					}
				}
			}
		}
	}
	
	xhr.open("POST","Organize1/getTicketDetails") ;
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	xhr.send("ticketId="+id);
	
	
}

function ticketDetailsViewCancel(){
	repValue.innerHTML="";
	ticketDetailsView.style.transform="translateX(251%)";
	adminContainer.style.pointerEvents="auto";
	adminContainer.style.filter="opacity(1)";
					
}





