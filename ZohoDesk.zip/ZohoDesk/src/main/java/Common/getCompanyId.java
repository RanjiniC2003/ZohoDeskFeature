package Common;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class getCompanyId {
  public static int getCompanyId(int userId) {
	  int companyId=0;
      try {
    	  	PreparedStatement psmt=Application.dbConnection.prepareStatement("select * from CompanyUsers where UserId=?");
			psmt.setInt(1,userId);
    	  	ResultSet rs2=psmt.executeQuery();
			if(rs2.next()) {
				companyId=rs2.getInt("companyId");
				return companyId;
			}
		    
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
      
	  return -1;
  }
}
