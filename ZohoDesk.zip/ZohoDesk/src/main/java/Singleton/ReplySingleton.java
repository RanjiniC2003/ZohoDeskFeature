package Singleton;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Classes.Reply;
import Common.Application;

public class ReplySingleton {
	 
	    
	    private static ReplySingleton object;

	    private ReplySingleton() {}

	    public static ReplySingleton getInstance() {
	        if (object==null) {
	            object=new ReplySingleton();
	        }
	        return object;
	    }

	    public Reply getReplyById(int replyId) throws SQLException {
	       
	        PreparedStatement psmt=Application.dbConnection.prepareStatement("select * from ticketReply where replyId=?");
	        psmt.setInt(1,replyId);
	        ResultSet rs=psmt.executeQuery();
	        if (rs.next()) {
	            Reply reply= Reply.fromResultSet(rs);
	            return reply;
	        }

	        return null;
	    }

}
