package Singleton;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import Classes.Ticket;
import Classes.subSection2;
import Common.Application;


public class TicketSingleton {
    private final HashMap<Integer, Ticket> map = new HashMap<>();
    
    private static TicketSingleton object;

    private TicketSingleton() {}

    public static TicketSingleton getInstance() {
        if (object==null) {
            object=new TicketSingleton();
        }
        return object;
    }

    public Ticket getTicketIdById(int ticketId) throws SQLException {
        if (map.containsKey(ticketId)) {
            return map.get(ticketId);
        }
        PreparedStatement psmt=Application.dbConnection.prepareStatement("select * from Ticket where ticketId=?");
        psmt.setInt(1,ticketId);
        ResultSet rs=psmt.executeQuery();
        if (rs.next()) {
        	Ticket ticket=Ticket.fromResultSet(rs);
            map.put(ticketId, ticket);
            return ticket;
        }

        return null;
    }
}
