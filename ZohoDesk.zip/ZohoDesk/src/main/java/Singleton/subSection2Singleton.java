package Singleton;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import Classes.subSection2;
import Common.Application;


public class subSection2Singleton {
    private final HashMap<Integer, subSection2> map = new HashMap<>();
    
    private static subSection2Singleton object;

    private subSection2Singleton() {}

    public static subSection2Singleton getInstance() {
        if (object==null) {
            object=new subSection2Singleton();
        }
        return object;
    }

    public subSection2 getSubSection2ById(int subSection2Id) throws SQLException {
        if (map.containsKey(subSection2Id)) {
            return map.get(subSection2Id);
        }
        PreparedStatement psmt=Application.dbConnection.prepareStatement("select * from subSection2 where SubSection2Id=?");
        psmt.setInt(1,subSection2Id);
        ResultSet rs=psmt.executeQuery();
        if (rs.next()) {
        	subSection2 subSec2Id= subSection2.fromResultSet(rs);
            map.put(subSection2Id, subSec2Id);
            return subSec2Id;
        }

        return null;
    }
}
