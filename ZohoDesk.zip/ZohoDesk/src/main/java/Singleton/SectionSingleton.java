package Singleton;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import Classes.Section;
import Common.Application;


public class SectionSingleton {
    private final HashMap<Integer, Section> map = new HashMap<>();
    
    private static SectionSingleton object;

    private SectionSingleton() {}

    public static SectionSingleton getInstance() {
        if (object==null) {
            object=new SectionSingleton();
        }
        return object;
    }

    public Section getSectionById(int sectionId) throws SQLException {
        if (map.containsKey(sectionId)) {
            return map.get(sectionId);
        }
        PreparedStatement psmt=Application.dbConnection.prepareStatement("select * from section where SectionId=?");
        psmt.setInt(1,sectionId);
        ResultSet rs=psmt.executeQuery();
        if (rs.next()) {
            Section section= Section.fromResultSet(rs);
            map.put(sectionId, section);
            return section;
        }

        return null;
    }
}
