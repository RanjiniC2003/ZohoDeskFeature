package Singleton;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import Classes.subSection1;
import Common.Application;


public class subSection1Singleton {
    private final HashMap<Integer, subSection1> map = new HashMap<>();
    
    private static subSection1Singleton object;

    private subSection1Singleton() {}

    public static subSection1Singleton getInstance() {
        if (object==null) {
            object=new subSection1Singleton();
        }
        return object;
    }

    public subSection1 getSubSectionById(int subSection1Id) throws SQLException {
        if (map.containsKey(subSection1Id)) {
            return map.get(subSection1Id);
        }
        PreparedStatement psmt=Application.dbConnection.prepareStatement("select * from subSection1 where SubSection1Id=?");
        psmt.setInt(1,subSection1Id);
        ResultSet rs=psmt.executeQuery();
        if (rs.next()) {
        	subSection1 subSec1Id= subSection1.fromResultSet(rs);
            map.put(subSection1Id, subSec1Id);
            return subSec1Id;
        }

        return null;
    }
}
