package Servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Jdbc.TicketJdbc;

/**
 * Servlet implementation class AdminTicketServlet
 */
@WebServlet("/Organize1/*")
public class AdminTicketServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminTicketServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path=request.getPathInfo();
		int userId=(int) request.getAttribute("userId");
		
		if(path.equals("/viewTickets")) {
	    	String type=request.getParameter("type");
	    	response.getWriter().write(TicketJdbc.viewTickets(type,userId,userId).toString());
	    }
		if(path.equals("/deleteTicket")) {
			String ticketId=request.getParameter("ticketId");
			response.getWriter().write(TicketJdbc.deleteTicket(Integer.parseInt(ticketId)).toString());
		}
		else if(path.equals("/updateTicket")) {
			String ticketSubject=request.getParameter("ticketSubject");
			String ticketDes=request.getParameter("ticketDes");
			String priority=request.getParameter("priority");
			String status=request.getParameter("status");
			String ticketId=request.getParameter("ticketId");
			
			response.getWriter().write(TicketJdbc.updateTicket(ticketSubject, ticketDes, priority, status,ticketId).toString());
		}
		else if(path.equals("/getTicketDetails")) {
			String ticketId=request.getParameter("ticketId");
			response.getWriter().write(TicketJdbc.getTicketDetails(Integer.parseInt(ticketId)).toString());
		}
		else if(path.equals("/addReply")) {
			String ticketId=request.getParameter("ticketId");
			String reply=request.getParameter("reply");
			response.getWriter().write(TicketJdbc.addReply(Integer.parseInt(ticketId),reply).toString());
		}
	}

}
