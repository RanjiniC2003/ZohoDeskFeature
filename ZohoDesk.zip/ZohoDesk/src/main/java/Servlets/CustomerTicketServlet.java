package Servlets;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import Classes.Company;
import Classes.User;
import Common.getCompanyId;
import Jdbc.CustomerSignJdbc;
import Jdbc.OrganizationJDBC;
import Jdbc.TicketJdbc;
import Singleton.UserSingleton;

/**
 * Servlet implementation class Customer
 */
@WebServlet("/Customer/*")
public class CustomerTicketServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerTicketServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path=request.getPathInfo();
		int userId=(int) request.getAttribute("userId");
		int companyId=getCompanyId.getCompanyId(userId);
		int ownerId=0;
		try {
			ownerId=Company.fromCompanyId(companyId).getSuperUser().getUserId();
		} catch (SQLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		int adminId = 0;
		try {
			adminId = Company.fromCompanyId(companyId).getSuperUser().getUserId();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		if(path.equals("/addTicket")) {
			String ticketSubject=request.getParameter("ticketSubject");
			String ticketDes=request.getParameter("ticketDes");
			String productName=request.getParameter("productName");
			String subSec1=request.getParameter("subSec1");
			String subSec2=request.getParameter("subSec2");
			String priority=request.getParameter("priority");
//			System.out.println(priority);
		    
			response.getWriter().write(TicketJdbc.addTicket(ticketSubject, ticketDes, productName, subSec1, subSec2, priority,userId,ownerId).toString());
		}
		
		
		else if(path.equals("/viewCustomerPage")) {
			JSONObject json=new JSONObject();
			User user=null;
			try {
				user=UserSingleton.getInstance().getUserById(userId);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			json.put("user", user.toJSON());
			json.put("message", "check user");
			response.getWriter().write(json.toString());
		}
		
		else if(path.equals("/sectionView")) {		
			response.getWriter().write(OrganizationJDBC.sectionView(adminId).toString());
			
		}
		else if(path.equals("/subSection1View")) {
	    	String sectionVal=request.getParameter("sectionVal");
//	    	System.out.println(sectionVal);
	    	response.getWriter().write(OrganizationJDBC.subSection1View(adminId, sectionVal).toString());
			
		}
	    else if(path.equals("/subSection2View")) {
	    	String subSec1Val=request.getParameter("subSec1Val");
	    	response.getWriter().write(OrganizationJDBC.subSection2View(adminId, subSec1Val).toString());
	    }
		
		
	    else if(path.equals("/viewTickets")) {
	    	String type=request.getParameter("type");
	    	response.getWriter().write(TicketJdbc.viewTickets(type,userId,ownerId).toString());
	    }
	    else if(path.equals("/getTicketDetails")) {
			String ticketId=request.getParameter("ticketId");
			response.getWriter().write(TicketJdbc.getTicketDetails(Integer.parseInt(ticketId)).toString());
		}
	}

}
