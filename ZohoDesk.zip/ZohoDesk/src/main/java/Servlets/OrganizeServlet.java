package Servlets;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import Classes.Section;
import Classes.subSection1;
import Classes.subSection2;
import Common.Application;
import Jdbc.OrganizationJDBC;
import Singleton.SectionSingleton;
import Singleton.UserSingleton;
import Singleton.subSection1Singleton;
import Singleton.subSection2Singleton;

/**
 * Servlet implementation class Organize
 */
@WebServlet("/Organize/*")
public class OrganizeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OrganizeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path=request.getPathInfo();
		
		int userId=(int) request.getAttribute("userId");
		
		
		if(path.equals("/addSection")) {
			JSONObject json=new JSONObject();
			String sectionName=request.getParameter("sectionName");
			String sectionDescription=request.getParameter("sectionDescription");
			String sectionVisibility=request.getParameter("sectionVisibility");
			String section=request.getParameter("section");
			if(section.equals("section")) {
				response.getWriter().write(OrganizationJDBC.section(sectionName, sectionDescription, sectionVisibility, userId).toString());
			}
			else if(section.equals("subSec1")) {
				String secVal=request.getParameter("secVal");
				response.getWriter().write(OrganizationJDBC.SubSec1(sectionName, sectionDescription, sectionVisibility, userId,secVal).toString());
				
			}
			else if(section.equals("subSec2")) {
				String subSec1Val=request.getParameter("subSec1Val");
				response.getWriter().write(OrganizationJDBC.SubSec2(sectionName, sectionDescription, sectionVisibility, userId, subSec1Val).toString());
			}
			
		}
		else if(path.equals("/sectionView")) {
			  response.getWriter().write(OrganizationJDBC.sectionView(userId).toString());
		}
	    else if(path.equals("/subSection1View")) {
	    	String sectionVal=request.getParameter("sectionVal");
//	    	System.out.println(sectionVal);
	    	response.getWriter().write(OrganizationJDBC.subSection1View(userId, sectionVal).toString());
			
		}
	    else if(path.equals("/subSection2View")) {
	    	String subSec1Val=request.getParameter("subSec1Val");
	    	response.getWriter().write(OrganizationJDBC.subSection2View(userId, subSec1Val).toString());
	    }
	}

}
