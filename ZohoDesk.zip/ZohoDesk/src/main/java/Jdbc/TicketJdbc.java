package Jdbc;

import java.sql.*;
import java.util.Date;

import org.json.JSONObject;
import org.json.simple.JSONArray;

import Classes.Reply;
import Classes.Ticket;
import Common.Application;
import Common.getCompanyId;
import Singleton.ReplySingleton;
import Singleton.TicketSingleton;

public class TicketJdbc {
	public static JSONObject addTicket(String subject,String des,String productName,String subSec1,String subSec2,String priority,int userId,int ownerId) {
		JSONObject json=new JSONObject();
		try {
			
			
			if(subject.trim().equals("") || subject.equals("")) {
			    json.put("statusCode",500);
				json.put("message","failed");
				json.put("detailedMessage", "Subject must be filled out");
				return json;
			}
			
			
			int sectionId=Integer.parseInt(productName);
			int subSecId1=Integer.parseInt(subSec1);
			int subSecId2=Integer.parseInt(subSec2);
		
			
//			PreparedStatement psmt1=Application.dbConnection.prepareStatement("select * from section where SectionName=?");
//			psmt1.setString(1, productName);
//			ResultSet rs1=psmt1.executeQuery();
//			if(rs1.next()) {
//				System.out.println("cvb");
//				sectionId=rs1.getInt("SectionId");
//			}
//			System.out.println(sectionId+" "+subSecId1+" "+subSecId2);
			
//			PreparedStatement psmt2=Application.dbConnection.prepareStatement("select * from subSection1 where SectionName=? and SectionId=?");
//			psmt2.setString(1, subSec1);
//			psmt2.setInt(2, sectionId);
//			ResultSet rs2=psmt2.executeQuery();
//			if(rs2.next()) {
//				subSecId1=rs2.getInt("SubSection1Id");
//			}
//			
//			PreparedStatement psmt3=Application.dbConnection.prepareStatement("select * from subSection2 where SectionName=? and SubSection1Id=?");
//			psmt3.setString(1, subSec2);
//			psmt3.setInt(2, subSecId1);
//			ResultSet rs3=psmt3.executeQuery();
//			if(rs3.next()) {
//				subSecId2=rs3.getInt("SubSection2Id");
//			}
			
			
			if(Integer.parseInt(subSec1)==-1) {
				subSecId1=-1;
			}
			if(Integer.parseInt(subSec2)==-1) {
				subSecId2=-1;
			}
			
			PreparedStatement psmt4=Application.dbConnection.prepareStatement("insert into Ticket(createdBy,Subject,Description,ProductId,Priority,status,createdOn,ownerId,SubSection1Id,SubSection2Id) values(?,?,?,?,?,?,?,?,?,?)");

		
			psmt4.setInt(1, userId);
			psmt4.setString(2, subject);
			psmt4.setString(3, des);
			psmt4.setInt(4,sectionId);
			
//			psmt4.setInt(6, subSecId2);
			psmt4.setString(5, priority);
			psmt4.setString(6,"Open");
			
			
			Date curDate = new Date();
			java.sql.Date stDate = new java.sql.Date(curDate.getTime());
			psmt4.setDate(7,stDate);
			psmt4.setInt(8, ownerId);
			
			
			
			if(subSecId1!=-1) {
				psmt4.setInt(9, subSecId1);
			}
			else {
				psmt4.setNull(9, java.sql.Types.NULL);
			}
			if(subSecId2!=-1) {
				psmt4.setInt(10, subSecId2);
			}
			else {
				psmt4.setNull(10, java.sql.Types.NULL);
			}
			psmt4.executeUpdate();
			
			json.put("statusCode",200);
			json.put("message", "Success");
			json.put("detailedMessage","Successfully Ticket added");
			return json;
			
		} catch (SQLException e) {
			e.printStackTrace();
			json.put("statusCode",500);
			json.put("message", "Failed");
			json.put("detailedMessage","Ticket not added");
			return json;
		}
	}
	
	
	public static JSONObject updateTicket(String subject,String des,String priority,String status,String ticketId) {
		JSONObject json=new JSONObject();
		try {
			PreparedStatement psmt1=Application.dbConnection.prepareStatement("update Ticket set Subject=?,Description=?,Priority=?,status=? where ticketId=?");
			psmt1.setString(1, subject);
			psmt1.setString(2,des);
			psmt1.setString(3, priority);
			psmt1.setString(4, status);
			psmt1.setInt(5, Integer.parseInt(ticketId));
			
			psmt1.executeUpdate();
			
			json.put("statusCode",200);
			json.put("message", "Success");
			json.put("detailedMessage","Successfully Ticket updated");
			return json;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			json.put("statusCode",500);
			json.put("message", "Failed");
			json.put("detailedMessage","Ticket not updated");
			return json;
		}
		
	}
	
	public static JSONObject viewTickets(String type,int userId,int ownerId) {
		JSONObject json=new JSONObject();
		JSONArray arr=new JSONArray();
		
		if(type.equals("viewAllTicket")) {
			
			try {
				PreparedStatement psmt=Application.dbConnection.prepareStatement("select * from Ticket where ownerId=?");
				psmt.setInt(1, ownerId);
				ResultSet rs=psmt.executeQuery();
				while(rs.next()) {
					Ticket ticket=TicketSingleton.getInstance().getTicketIdById(rs.getInt("ticketId"));
					arr.add(ticket.toJSON());
				}
				json.put("statusCode", 200);
				json.put("message", "SUCCESS");
				json.put("arr",arr);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if(type.equals("viewMyTicket")) {
			try {
				PreparedStatement psmt=Application.dbConnection.prepareStatement("select * from Ticket where createdBy=?");
				psmt.setInt(1, userId);
				ResultSet rs=psmt.executeQuery();
				while(rs.next()) {
					Ticket ticket=TicketSingleton.getInstance().getTicketIdById(rs.getInt("ticketId"));
					arr.add(ticket.toJSON());
				}
				json.put("statusCode", 200);
				json.put("message", "SUCCESS");
				json.put("arr",arr);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return json;
	}
	
	public static JSONObject deleteTicket(int ticketId) {
		JSONObject json=new JSONObject();
		try {
			PreparedStatement psmt=Application.dbConnection.prepareStatement("delete from Ticket where ticketId=?");
			psmt.setInt(1, ticketId);
			psmt.executeUpdate();
			
			json.put("statusCode",200);
			json.put("message", "SUCCESS");
			json.put("detailedMessage", "Successfully ticket deleted");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return json;
	}
	
	public static JSONObject getTicketDetails(int ticketId) {
		JSONObject json=new JSONObject();
		JSONArray arr=new JSONArray();
		try {
			PreparedStatement psmt=Application.dbConnection.prepareStatement("select * from Ticket where ticketId=?");
			psmt.setInt(1, ticketId);
			ResultSet rs=psmt.executeQuery();
			if(rs.next()) {
				json.put("ticket",TicketSingleton.getInstance().getTicketIdById(rs.getInt("ticketId")).toJSON());
			}
			PreparedStatement psmt2=Application.dbConnection.prepareStatement("select * from ticketReply where ticketId=?");
			psmt2.setInt(1, ticketId);
			ResultSet rs2=psmt2.executeQuery();
			while(rs2.next()) {
				Reply reply=ReplySingleton.getInstance().getReplyById(rs2.getInt("replyId"));
			    arr.add(reply.toJSON());
			}
			json.put("arr", arr);
			json.put("statusCode",200);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return json;
	}
	
	public static JSONObject addReply(int ticketId,String reply) {
		JSONObject json=new JSONObject();
		try {
			PreparedStatement psmt=Application.dbConnection.prepareStatement("insert into ticketReply(ticketId,replay) values(?,?)");
			psmt.setInt(1, ticketId);
			psmt.setString(2, reply);
			psmt.executeUpdate();
			
			json.put("statusCode",200);
			json.put("message","Success");
			json.put("detailedMessage", "Reply successfully added");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return json;
	}
}
