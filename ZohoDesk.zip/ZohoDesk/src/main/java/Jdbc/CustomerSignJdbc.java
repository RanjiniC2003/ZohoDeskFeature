package Jdbc;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.UUID;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;

import Common.Application;
import Common.CookieManagement;
import Common.getCompanyId;

public class CustomerSignJdbc {
	

	
	public static JSONObject signIn(String email,String password,HttpServletResponse response) {
		JSONObject responseJSON = new JSONObject();
		Statement st = null;
		try {
			st = Application.dbConnection.createStatement();
			PreparedStatement psmt=Application.dbConnection.prepareStatement("select * from Users where email=?");
			psmt.setString(1, email);
			ResultSet rs=psmt.executeQuery();
			if(rs.next()) {
				if(String.valueOf(rs.getString("email")).equals(email) && String.valueOf(rs.getString("password")).equals(password)) {
					
					int userId=rs.getInt("userId");
					UUID sessionId=UUID.randomUUID();
					CookieManagement.setCookie(response, "CUSTOMERSESSIONID", String.valueOf(sessionId));

					PreparedStatement psmt2=Application.dbConnection.prepareStatement("insert into session values(?,?)");
					psmt2.setString(1, String.valueOf(sessionId));
					psmt2.setInt(2, userId);
					psmt2.executeUpdate();
					
					responseJSON.put("statusCode", 200);
					responseJSON.put("statusMessage", "SUCCESS");
					responseJSON.put("detailedMessage", "sign in Successful");
					return responseJSON;
					
				}
			}
			else {
				responseJSON.put("statusCode", 500);
				responseJSON.put("statusMessage", "Failed");
				responseJSON.put("detailedMessage", "Invalid email or password");
				return responseJSON;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			responseJSON.put("statusCode", 500);
			responseJSON.put("statusMessage", "Failed");
			responseJSON.put("detailedMessage", "Invalid email or password");
			return responseJSON;
		}
		return responseJSON;
	}
	
	
	
	public static JSONObject signUp(String firstName,String lastName,String email,String password,String phoneNumber,HttpServletResponse response) throws JSONException, IOException {
		JSONObject responseJSON = new JSONObject();
	    final Pattern namePattern = Pattern.compile("^[A-Za-z. ]+$");
	    final Pattern lastPattern = Pattern.compile("^[A-Za-z]+$");
	    final Pattern emailPattern = Pattern.compile("^[a-z0-9]+(?:\\.[a-z0-9]+)*@[a-z]+(?:\\.[a-z]+)*$");
	    final Pattern passPattern = Pattern.compile("^(?=.*[A-Z])(?=.*[a-z])(?=.*[!@#$%^&* )(+=._-])(?=.*[0-9])[A-Za-z0-9!@#$%^&* )(+=._-]{8,}$");
	    final Pattern phoneNumPattern = Pattern.compile("^[0-9]{10}$");

        if (!namePattern.matcher(firstName).find()) {
            responseJSON.put("statusCode", 400);
            responseJSON.put("statusMessage", "FAILURE");
            responseJSON.put("detailedMessage", "Invalid First name");
            return responseJSON;
        }

        if (!lastPattern.matcher(lastName).find()) {
            responseJSON.put("statusCode", 400);
            responseJSON.put("statusMessage", "FAILURE");
            responseJSON.put("detailedMessage", "Invalid last name");
            return responseJSON;
        }
        if (!emailPattern.matcher(email).find()) {
            responseJSON.put("statusCode", 400);
            responseJSON.put("statusMessage", "FAILURE");
            responseJSON.put("detailedMessage", "Invalid email");
            return responseJSON;
        }

        if (!passPattern.matcher(password).find()) {
            responseJSON.put("statusCode", 400);
            responseJSON.put("statusMessage", "FAILURE");
            responseJSON.put("detailedMessage", "Invalid Password");
            return responseJSON;
        }
        
        if (!phoneNumPattern.matcher(phoneNumber).find()) {
            responseJSON.put("statusCode", 400);
            responseJSON.put("statusMessage", "FAILURE");
            responseJSON.put("detailedMessage", "Invalid Phone number");
            return responseJSON;
        }
        try {
            PreparedStatement psmt=Application.dbConnection.prepareStatement("insert into Users(firstName,lastName,email,password,phoneNumber) values(?,?,?,?,?)");
            psmt.setString(1,firstName );
            psmt.setString(2, lastName);
            psmt.setString(3, email);
            psmt.setString(4,password);
            psmt.setBigDecimal(5, new BigDecimal(phoneNumber));
            psmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        int userId=0;
        Statement st = null;
        try {
            st = Application.dbConnection.createStatement();
        } catch (SQLException e2) {
            System.out.println(e2.getMessage());
        }
        try {
            ResultSet rs=st.executeQuery("select * from Users where phoneNumber="+phoneNumber);
            if(rs.next()) {
                rs.getInt("userId");
                userId=rs.getInt("userId");
            }

        } catch (SQLException e1) {
            System.out.println(e1.getMessage());
        }
        

        
        
		UUID sessionId=UUID.randomUUID();
		CookieManagement.setCookie(response, "CUSTOMERSESSIONID", String.valueOf(sessionId));
        
		

		PreparedStatement psmt2;
		try {
			psmt2 = Application.dbConnection.prepareStatement("insert into session values(?,?)");
			psmt2.setString(1, String.valueOf(sessionId));
			psmt2.setInt(2, userId);
			psmt2.executeUpdate();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	
		
        
        
//        int companyId=getCompanyId.getCompanyId(userId);
        

        try {
			PreparedStatement pst=Application.dbConnection.prepareStatement("insert into CompanyUsers values(?,?,?)");
            pst.setInt(1,1 );
            pst.setInt(2,userId);
            
            Date joinDate=new Date();
			pst.setInt(3, 1);
			pst.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}        
        responseJSON.put("statusCode", 200);
        responseJSON.put("statusMessage", "SUCCESS");
        responseJSON.put("detailedMessage", "sign up Successful");   
		return responseJSON;
	}
}
