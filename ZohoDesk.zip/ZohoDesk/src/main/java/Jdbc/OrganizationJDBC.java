package Jdbc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.json.JSONObject;
import org.json.simple.JSONArray;

import Classes.Section;
import Classes.subSection1;
import Classes.subSection2;
import Common.Application;
import Singleton.SectionSingleton;
import Singleton.UserSingleton;
import Singleton.subSection1Singleton;
import Singleton.subSection2Singleton;

public class OrganizationJDBC {
	public static JSONObject section(String sectionName,String sectionDescription,String sectionVisibility,int userId) {
		JSONObject json=new JSONObject();
		try {
			PreparedStatement psmt1=Application.dbConnection.prepareStatement("insert into section(SectionName,Description,Visibility,createdBy) values(?,?,?,?)");
			psmt1.setString(1, sectionName);
			psmt1.setString(2, sectionDescription);
			psmt1.setString(3, sectionVisibility);
			psmt1.setInt(4, userId);
			
			psmt1.executeUpdate();
			
			json.put("statusCode", 200);
			json.put("message","Success");
			json.put("detailedMessage", "Section successfully added");
			
			return json;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			json.put("statusCode", 500);
			json.put("message","Failed");
			json.put("detailedMessage", "Section not added");
		
			return json;
		}
	}
	
	public static JSONObject SubSec1(String sectionName,String sectionDescription,String sectionVisibility,int userId,String secVal) {
		JSONObject json=new JSONObject();
		try {
			PreparedStatement psmt1=Application.dbConnection.prepareStatement("insert into subSection1(SectionName,Description,Visibility,SectionId,createdBy) values(?,?,?,?,?)");
			psmt1.setString(1, sectionName);
			psmt1.setString(2, sectionDescription);
			psmt1.setString(3, sectionVisibility);
			psmt1.setInt(4, Integer.parseInt(secVal));
			psmt1.setInt(5, userId);
			
			psmt1.executeUpdate();
			
			json.put("statusCode", 200);
			json.put("message","Success");
			json.put("detailedMessage", "Section successfully added");
			return json;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			json.put("statusCode", 500);
			json.put("message","Failed");
			json.put("detailedMessage", "Subsection not added");
			return json;
	    }
	}
	
	public static JSONObject SubSec2(String sectionName,String sectionDescription,String sectionVisibility,int userId,String subSec1Val){
		
		JSONObject json=new JSONObject();
		try {
			PreparedStatement psmt1=Application.dbConnection.prepareStatement("insert into subSection2(SectionName,Description,Visibility,SubSection1Id,createdBy) values(?,?,?,?,?)");
			psmt1.setString(1, sectionName);
			psmt1.setString(2, sectionDescription);
			psmt1.setString(3, sectionVisibility);
			psmt1.setInt(4, Integer.parseInt(subSec1Val));
			psmt1.setInt(5, userId);
			
			psmt1.executeUpdate();
			
			json.put("statusCode", 200);
			json.put("message","Success");
			json.put("detailedMessage", "Subsection successfully added");
			return json;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			json.put("statusCode", 500);
			json.put("message","Failed");
			json.put("detailedMessage", "Section not added");
			return json;
	    }
	}
	
	public static JSONObject sectionView(int userId) {
		JSONObject json=new JSONObject();
		try {
			
			JSONArray arr=new JSONArray();
			
			
			PreparedStatement psmt1=Application.dbConnection.prepareStatement("select * from section where createdBy=?");
			psmt1.setInt(1, userId);
			ResultSet rs=psmt1.executeQuery();
			while(rs.next()) {
				Section section=SectionSingleton.getInstance().getSectionById(rs.getInt("SectionId"));
				arr.add(section.toJSON());
			}
			json.put("User",UserSingleton.getInstance().getUserById(userId).toJSON());
			json.put("statusCode", 200);
			json.put("message","Successful");
			json.put("sectionList", arr);
			return json;
			
		} catch (SQLException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
			json.put("statusCode", 500);
			json.put("message","Failed");
			return json;
		}
	}
	
	public static JSONObject subSection1View(int userId,String sectionVal) {
		JSONObject json=new JSONObject();
    	JSONArray arr=new JSONArray();
    	PreparedStatement psmt2;
		try {
			psmt2 = Application.dbConnection.prepareStatement("select * from subSection1 where createdBy=? and  SectionId=?");
			psmt2.setInt(1, userId);
			psmt2.setInt(2, Integer.parseInt(sectionVal));
			ResultSet rs2=psmt2.executeQuery();
			while(rs2.next()) {
//				System.out.println("jk");
				subSection1 subsection1=subSection1Singleton.getInstance().getSubSectionById(rs2.getInt("SubSection1Id"));
				arr.add(subsection1.toJSON());
			}
			json.put("User",UserSingleton.getInstance().getUserById(userId).toJSON());
			json.put("statusCode", 200);
			json.put("message","Successful");
			json.put("subSec1", arr);
			return json;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			json.put("statusCode", 500);
			json.put("message","Failed");
			return json;
		}
	}
	
	public static JSONObject subSection2View(int userId,String subSec1Val) {
		JSONArray arr=new JSONArray();
    	JSONObject json=new JSONObject();
    	try {
    		
    		PreparedStatement psmt3=Application.dbConnection.prepareStatement("select * from subSection2 where createdBy=? and SubSection1Id=?");
			psmt3.setInt(1, userId);
			psmt3.setInt(2, Integer.parseInt(subSec1Val));
			ResultSet rs3=psmt3.executeQuery();
			while(rs3.next()) {
				subSection2 subsection2=subSection2Singleton.getInstance().getSubSection2ById(rs3.getInt("SubSection2Id"));
				arr.add(subsection2.toJSON());
			}
			
			json.put("User",UserSingleton.getInstance().getUserById(userId).toJSON());
			json.put("statusCode", 200);
			json.put("message","Successful");
			json.put("subSec2", arr);
			return json;
			
		} catch (SQLException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
			json.put("statusCode", 500);
			json.put("message","Failed");;
			return json;
		}
	}
}
