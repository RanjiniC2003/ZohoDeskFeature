package Classes;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.json.JSONObject;

import Singleton.SectionSingleton;
import Singleton.UserSingleton;

public class subSection1 {
	private int subSection1Id;
	private String subSection1Name;
	private String description;
	private String visibility;
	private User createdBy;
	private Section section;
	
	public subSection1(int subSection1Id,String subSection1Name,String description,String visibility,User createdBy,Section section) {
		this.subSection1Id=subSection1Id;
		this.subSection1Name=subSection1Name;
		this.description=description;
		this.visibility=visibility;
		this.createdBy=createdBy;
		this.section=section;
	}

	public int getSubSectionId() {
		return subSection1Id;
	}

	public void setSubSectionId(int subSectionId) {
		this.subSection1Id = subSectionId;
	}

	public String getSubSectionName() {
		return subSection1Name;
	}

	public void setSubSectionName(String subSectionName) {
		this.subSection1Name = subSectionName;
	}
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getVisibility() {
		return visibility;
	}

	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}

	public User getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}
	public Section getSection() {
		return section;
	}

	public void setSection(Section section) {
		this.section = section;
	}

	public static subSection1 fromResultSet(ResultSet rs) throws SQLException {
		
		int sessionId=rs.getInt("SubSection1Id");
		String sessionName=rs.getString("SectionName");
		String description=rs.getString("Description");
		String visibility=rs.getString("Visibility");
		Section section=SectionSingleton.getInstance().getSectionById(rs.getInt("SectionId"));
		User createdBy=UserSingleton.getInstance().getUserById(rs.getInt("createdBy"));
		

	return new subSection1(sessionId, sessionName, description, visibility,createdBy,section );
	
	}
	
	
	
	public JSONObject toJSON() {
		JSONObject json = new JSONObject();
		json.put("subSectionId", this.subSection1Id);
	    json.put("subSectionName", this.subSection1Name);
	    json.put("Description", this.description);
	    json.put("Visibility", this.visibility);
	    json.put("section", this.section);
	    json.put("createdBy", this.createdBy);
	    
	    
	    return json;
	}
	
	public String toString() {
		return this.toJSON().toString();
	}
}
