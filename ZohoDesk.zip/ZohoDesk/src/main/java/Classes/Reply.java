package Classes;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.json.JSONObject;

import Singleton.TicketSingleton;
import Singleton.UserSingleton;

public class Reply {
	private int replyId;
	private String replyName;
	private Ticket ticket;
	
	
	public Reply(int replyId,String replayName,Ticket ticket) {
		this.replyName=replayName;
		this.ticket=ticket;
		this.replyId=replyId;
	}
    
	
	

	public int getReplyId() {
		return replyId;
	}
	public void setReplyId(int replyId) {
		this.replyId = replyId;
	}
	public String getReplyName() {
		return replyName;
	}


	public void setReplyName(String replyName) {
		this.replyName = replyName;
	}


	public Ticket getTicket() {
		return ticket;
	}


	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}
	
public static Reply fromResultSet(ResultSet rs) throws SQLException {
		int replyId=rs.getInt("replyId");
		Ticket ticketId=TicketSingleton.getInstance().getTicketIdById(rs.getInt("ticketId"));
		String reply=rs.getString("replay");
		
		

	return new Reply(replyId,reply, ticketId);
	
	}
	
	
	
	public JSONObject toJSON() {
		JSONObject json = new JSONObject();
		json.put("replyId", this.replyId);
		json.put("ticket", this.ticket.toJSON());
	    json.put("reply", this.replyName);
	    return json;
	}
	
	public String toString() {
		return this.toJSON().toString();
	}
	
}
