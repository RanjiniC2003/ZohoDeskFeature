package Classes;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.json.JSONObject;

import Singleton.SectionSingleton;
import Singleton.UserSingleton;
import Singleton.subSection1Singleton;
import Singleton.subSection2Singleton;

public class Ticket {
	private int ticketId;
	private User user;
	private String subject;
	private String description;
	private Section product;
	private subSection1 subSec1;
	private subSection2 subSec2;
	private String priority;
	private User owner;
	private String status;
	private Date createdOn;
	
	public Ticket(int ticketId,User user,String subject,String description,Section product,subSection1 subSec1,subSection2 subSec2,String priority,User owner,String status,Date createdOn) {
		this.ticketId=ticketId;
		this.user=user;
		this.subject=subject;
		this.description=description;
		this.product=product;
		this.subSec1=subSec1;
		this.subSec2=subSec2;
		this.priority=priority;
		this.owner=owner;
		this.status=status;
		this.createdOn=createdOn;
	}

	public int getTicketId() {
		return ticketId;
	}

	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Section getProduct() {
		return product;
	}

	public void setProduct(Section product) {
		this.product = product;
	}

	public subSection1 getSubSec1() {
		return subSec1;
	}

	public void setSubSec1(subSection1 subSec1) {
		this.subSec1 = subSec1;
	}

	public subSection2 getSubSec2() {
		return subSec2;
	}

	public void setSubSec2(subSection2 subSec2) {
		this.subSec2 = subSec2;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}
	public User getOwner() {
		return owner;
	}

	public void setOwner(User owner) {
		this.owner = owner;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public static Ticket fromResultSet(ResultSet rs) throws SQLException {
		
		int ticketId=rs.getInt("ticketId");
		User createdBy=UserSingleton.getInstance().getUserById(rs.getInt("createdBy"));
		String Subject=rs.getString("Subject");
		String Description=rs.getString("Description");
		Section section=SectionSingleton.getInstance().getSectionById(rs.getInt("ProductId"));
		subSection1 subsection1=subSection1Singleton.getInstance().getSubSectionById(rs.getInt("SubSection1Id"));
		subSection2 subsection2=subSection2Singleton.getInstance().getSubSection2ById(rs.getInt("SubSection1Id"));
		String priority=rs.getString("Priority");
		User owner=UserSingleton.getInstance().getUserById(rs.getInt("ownerId"));
		String status=rs.getString("status");
		Date createdOn=rs.getDate("createdOn");

	    return new Ticket(ticketId,createdBy,Subject, Description, section, subsection1,subsection2,priority,owner,status,createdOn);
	
	}
	
	
	
	public JSONObject toJSON() {
		JSONObject json = new JSONObject();
		json.put("ticketId", this.ticketId);
	    json.put("createdBy", this.user.toJSON());
	    json.put("Subject", this.subject);
	    json.put("Description", this.description);
	    json.put("section", this.product.toJSON());
	    json.put("subsection1",this.subSec1);
	    json.put("subsection2", this.subSec2);
	    json.put("priority", this.priority);
	    json.put("owner",this.owner.toJSON());
	    json.put("status", this.status);
	    json.put("createdOn",this.createdOn);
	    return json;
	}
	
	public String toString() {
		return this.toJSON().toString();
	}
	
}
