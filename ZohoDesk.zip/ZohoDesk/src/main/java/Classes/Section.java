package Classes;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.json.JSONObject;

import Singleton.UserSingleton;

public class Section {
	private int sectionId;
	private String sectionName;
	private String description;
	private String visibility;
	private User createdBy;
	
	public Section(int sectionId,String sectionName,String description,String visibility,User createdBy) {
		this.sectionId=sectionId;
		this.sectionName=sectionName;
		this.description=description;
		this.visibility=visibility;
		this.createdBy=createdBy;
	}

	public int getSectionId() {
		return sectionId;
	}

	public void setSectionId(int sectionId) {
		this.sectionId = sectionId;
	}

	public String getSectionName() {
		return sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getVisibility() {
		return visibility;
	}

	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}

	public User getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}
	
	
	
	public static Section fromResultSet(ResultSet rs) throws SQLException {
		
		int sessionId=rs.getInt("SectionId");
		String sessionName=rs.getString("SectionName");
		String description=rs.getString("Description");
		String visibility=rs.getString("Visibility");
		User createdBy=UserSingleton.getInstance().getUserById(rs.getInt("createdBy"));
		

	return new Section(sessionId, sessionName, description, visibility,createdBy );
	
	}
	
	
	
	public JSONObject toJSON() {
		JSONObject json = new JSONObject();
		json.put("SectionId", this.sectionId);
	    json.put("SectionName", this.sectionName);
	    json.put("Description", this.description);
	    json.put("Visibility", this.visibility);
	    json.put("createdBy", this.createdBy);
	    
	    
	    return json;
	}
	
	public String toString() {
		return this.toJSON().toString();
	}
}
