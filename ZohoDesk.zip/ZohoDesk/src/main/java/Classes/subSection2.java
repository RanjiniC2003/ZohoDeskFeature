package Classes;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.json.JSONObject;
import Singleton.UserSingleton;
import Singleton.subSection1Singleton;
public class subSection2 {
	private int subSectionId;
	private String subSectionName;
	private String description;
	private String visibility;
	private User createdBy;
	private subSection1 subSection;
	
	public subSection2(int subSectionId,String subSectionName,String description,String visibility,User createdBy,subSection1 subSection) {
		this.subSectionId=subSectionId;
		this.subSectionName=subSectionName;
		this.description=description;
		this.visibility=visibility;
		this.createdBy=createdBy;
		this.subSection=subSection;
	}

	public int getSubSectionId() {
		return subSectionId;
	}

	public void setSubSectionId(int subSectionId) {
		this.subSectionId = subSectionId;
	}

	public String getSubSectionName() {
		return subSectionName;
	}

	public void setSubSectionName(String subSectionName) {
		this.subSectionName = subSectionName;
	}
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getVisibility() {
		return visibility;
	}

	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}

	public User getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}
	public subSection1 getSection() {
		return subSection;
	}

	public void setSection(subSection1 subSection) {
		this.subSection = subSection;
	}

	public static subSection2 fromResultSet(ResultSet rs) throws SQLException {
		
		int sessionId=rs.getInt("SubSection2Id");
		String sessionName=rs.getString("SectionName");
		String description=rs.getString("Description");
		String visibility=rs.getString("Visibility");
		subSection1 subSection1=subSection1Singleton.getInstance().getSubSectionById(rs.getInt("SubSection1Id"));
		User createdBy=UserSingleton.getInstance().getUserById(rs.getInt("createdBy"));
		

	return new subSection2(sessionId, sessionName, description, visibility,createdBy,subSection1 );
	
	}
	
	
	
	public JSONObject toJSON() {
		JSONObject json = new JSONObject();
		json.put("subSectionId", this.subSectionId);
	    json.put("subSectionName", this.subSectionName);
	    json.put("Description", this.description);
	    json.put("Visibility", this.visibility);
	    json.put("section", this.subSectionId);
	    json.put("createdBy", this.createdBy);
	    
	    
	    return json;
	}
	
	public String toString() {
		return this.toJSON().toString();
	}
	

}
